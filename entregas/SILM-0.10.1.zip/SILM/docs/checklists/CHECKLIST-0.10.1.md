# Checklist — SILM 0.10.1 (correção de origem: gramática da família)

| Item | Situação | Evidência |
|---|---|---|
| Núcleo = Base Estrutural 0.3.1, sem alteração local | ✅ | auditoria "Núcleo herdado preservado" (`docs/evidence/NUCLEO-PRESERVADO.json`, 52 arquivos) |
| Abertura oficial sobre a camada da família; preferência em Acessibilidade; migração única | ✅ | itens 0.9-ID1, 0.9-ID2, 0.9-ID3 e 0.10.1-MENU |
| Página inicial editorial (R01) | ✅ | item 0.10.1-HOME |
| Como deseja iniciar? com cartões e convite (R02) | ✅ | item 0.10.1-START |
| Menu: Agora com metal e módulo, Montagens prontas (R04) | ✅ | item 0.10.1-MENU |
| Acessibilidade da família, nota de cores (R05) | ✅ | item 0.10.1-MENU |
| R06: Tabela Periódica cabe na cena (≥ 768 px); no celular, rola com dica | ✅ | item 0.10.1-R06 (1920, 1366, 1024, 768, 390) |
| Montagem por grupos e cartões de módulo numerados (R09, R14) | ✅ | item 0.10.1-MONT |
| Ver em famílias e Dados como ponto de partida, com "Dados do metal" (R10, R11) | ✅ | item 0.10.1-VER |
| Tour com nota de boas-vindas; sobretítulos da cena (R13) | ✅ | item 0.10.1-TOUR |
| Montagens prontas Cu · CFC, Fe · CCC, Mg · HC (R22) | ✅ | item 0.10.1-PRESET |
| Aprender em lista; Investigar seleciona o metal do tema (R18) | ✅ | item 0.10.1-APRENDER |
| Som e vibração das medições, desligados por padrão (R23, parte da família) | ✅ | item 0.10.1-SOM |
| Regressões 0.4.x a 0.10.0 | ✅ | suítes s040 a s100 completas |
| Nenhum dado científico alterado (schema 8) | ✅ | `validate-scientific-state.cjs`; `validate-scientific-data.cjs` |
| Revisão adversarial: 15 achados confirmados corrigidos (grupos do SILM nas atividades, Agora com a atividade, Concluir missão, Dados do metal, tema que redesenha, confirmação verdadeira da montagem pronta, Calcular limpo, som 8–12, caminhos e rótulos do Manual, Sobre o SILM, M6) | ✅ | itens 0.10.1-REV e 0.10.1-SOM |
| Núcleo corrigido pela Base, não pelo produto: Base 0.3.1 (confirmação declarada, também conforme o estado; segurança da abertura; `opening.stop()`, também no aviso de falha) | ✅ | Base 0.3.1: 92/92 testes; `docs/evidence/NUCLEO-PRESERVADO.json` |
| Segunda verificação independente (Manual, resetCalc, montagem pronta sem investigação, atividade restrita sem metal, documentos) | ✅ | item 0.10.1-REV |
| Objetivos ao vivo de missões com passos, com `activityPanel:false` | ⏳ R19 | antes das missões M1–M6: outra superfície para os objetivos ou o painel da atividade de volta |
| R19 missões temáticas | ⏳ rascunho | `docs/MISSOES-TEMATICAS-RASCUNHO.md` (aguarda validação do autor) |
| R23 som de cada metal pela física | ⏳ pesquisa | precisa de fonte verificável (velocidade do som em barra fina, CRC); a rede do ambiente bloqueia as fontes |
